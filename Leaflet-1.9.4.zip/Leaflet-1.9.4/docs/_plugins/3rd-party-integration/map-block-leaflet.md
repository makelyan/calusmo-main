---
name: Map Block Leaflet
category: 3rd-party-integration
repo: https://wordpress.org/plugins/map-block-leaflet/
author: Jesús Olazagoitia
author-url: https://goiblas.com/
demo: 
compatible-v0:
compatible-v1: true
---

A Block for the New WordPress Block Editor based on Leaflet, it allow add and custom maps from a visual interface.
