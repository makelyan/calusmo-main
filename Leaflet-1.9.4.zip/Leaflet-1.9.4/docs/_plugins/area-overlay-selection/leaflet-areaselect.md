---
name: Leaflet.AreaSelect
category: area-overlay-selection
repo: https://github.com/heyman/leaflet-areaselect/
author: Jonatan Heyman
author-url: https://heyman.info/
demo: https://heyman.github.io/leaflet-areaselect/example/
compatible-v0:
compatible-v1: true
---

A fixed positioned, resizable rectangle for selecting an area on the map.
