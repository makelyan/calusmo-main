---
name: Leaflet.bpg
category: basemap-formats
repo: https://github.com/balrog-kun/Leaflet.bpg
author: Andrzej Zaborowski
author-url: https://github.com/balrog-kun/
demo: 
compatible-v0:
compatible-v1: true
---

TileLayer with <a href="https://bellard.org/bpg/">.bpg</a> image format decoding.
