---
name: Leaflet.ImageOverlay.OGCAPI
category: basemap-formats
repo: https://gitlab.com/IvanSanchez/leaflet.imageoverlay.ogcapi
author: Iván Sánchez Ortega
author-url: https://ivan.sanchezortega.es
demo: https://ivansanchez.gitlab.io/leaflet.imageoverlay.ogcapi/demo.html
compatible-v0: false
compatible-v1: true
---

A client for the (untiled) [OGC API Maps](https://ogcapi.ogc.org/maps/) draft specification.
