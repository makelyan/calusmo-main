---
name: leaflet.TileLayer.WMTS
category: basemap-formats
repo: https://github.com/alexandre-melard/leaflet.TileLayer.WMTS
author: Alexandre Melard
author-url: https://github.com/mylen
demo: 
compatible-v0:
compatible-v1: true
---

Add WMTS (IGN) layering for leaflet.
