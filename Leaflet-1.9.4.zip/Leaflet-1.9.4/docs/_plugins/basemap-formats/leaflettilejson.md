---
name: leaflet-tilejson
category: basemap-formats
repo: https://github.com/kartena/leaflet-tilejson
author: Per Liedman
author-url: https://github.com/perliedman
demo: 
compatible-v0:
compatible-v1: true
---

Adds support for the <a href="https://github.com/mapbox/tilejson-spec">TileJSON</a> specification to Leaflet.
