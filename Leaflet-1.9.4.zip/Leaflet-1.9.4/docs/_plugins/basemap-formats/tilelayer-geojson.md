---
name: TileLayer.GeoJSON
category: basemap-formats
repo: https://github.com/glenrobertson/leaflet-tilelayer-geojson/
author: Glen Robertson
author-url: https://github.com/glenrobertson
demo: 
compatible-v0:
compatible-v1: true
---

A TileLayer for GeoJSON tiles.
