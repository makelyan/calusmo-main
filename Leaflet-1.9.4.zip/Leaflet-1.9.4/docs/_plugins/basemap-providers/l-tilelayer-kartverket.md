---
name: L.TileLayer.Kartverket
category: basemap-providers
repo: https://github.com/knreise/L.TileLayer.Kartverket
author: Kultur og naturreise
author-url: https://github.com/knreise
demo: 
compatible-v0:
compatible-v1: true
---

Provides easy setup of the tile layers from <a href="https://kartverket.no/standardisering/">Kartverket</a> (The Norwegian Mapping Authority)
