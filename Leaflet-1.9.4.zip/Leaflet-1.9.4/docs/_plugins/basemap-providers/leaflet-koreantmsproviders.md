---
name: Leaflet.KoreanTmsProviders
category: basemap-providers
repo: https://github.com/tontita/Leaflet.KoreanTmsProviders
author: Seong Choi
author-url: https://github.com/tontita/
demo: 
compatible-v0:
compatible-v1: true
---

Contains configurations for various (South) Korean tile providers — Daum, Naver, VWorld, etc.
