---
name: leaflet-providers
category: basemap-providers
repo: https://github.com/leaflet-extras/leaflet-providers
author: leaflet-extras members
author-url: https://github.com/leaflet-extras
demo: https://leaflet-extras.github.io/leaflet-providers/preview/
compatible-v0:
compatible-v1: true
---

Contains configurations for various free tile providers — OSM, OpenCycleMap, Stamen, Esri, etc.
