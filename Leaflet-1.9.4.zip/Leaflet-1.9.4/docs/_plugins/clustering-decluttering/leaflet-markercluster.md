---
name: Leaflet.markercluster
category: clustering-decluttering
repo: https://github.com/Leaflet/Leaflet.markercluster
author: Dave Leaver
author-url: https://github.com/danzel
demo: https://leaflet.github.io/Leaflet.markercluster/example/marker-clustering-realworld.388.html
compatible-v0:
compatible-v1: true
---

Beautiful, sophisticated, high performance marker clustering solution with smooth animations and lots of great features. <em>Recommended!</em>
