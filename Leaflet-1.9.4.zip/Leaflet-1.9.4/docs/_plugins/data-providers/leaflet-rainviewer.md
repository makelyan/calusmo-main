---
name: Leaflet.Rainviewer
category: data-providers
repo: https://github.com/mwasil/Leaflet.Rainviewer
author: Marcin Wasilewski
author-url: https://marcinwasilewski.eu/
demo: https://mwasil.github.io/Leaflet.Rainviewer/demo/
compatible-v0:
compatible-v1: true
---

Plugin for RainViewer radar data API.
