---
name: leaflet-environmental-layers
category: data-providers
repo: https://github.com/publiclab/leaflet-environmental-layers
author: Public Lab
author-url: https://github.com/publiclab
demo: https://publiclab.github.io/leaflet-environmental-layers/example/index.html#3/43.00/-46.26/BL2
compatible-v0:
compatible-v1: true
---

Collection of different environmental map layers in an easy to use Leaflet library.
