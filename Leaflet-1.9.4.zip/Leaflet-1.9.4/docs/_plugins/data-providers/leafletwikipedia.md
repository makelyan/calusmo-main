---
name: Leaflet-Wikipedia
category: data-providers
repo: https://github.com/MatthewBarker/leaflet-wikipedia
author: Matthew Barker
author-url: https://github.com/MatthewBarker
demo: https://matthewbarker.github.io/leaflet-wikipedia/
compatible-v0:
compatible-v1: true
---

A leaflet plugin to display Wikipedia API entries on a map layer.
