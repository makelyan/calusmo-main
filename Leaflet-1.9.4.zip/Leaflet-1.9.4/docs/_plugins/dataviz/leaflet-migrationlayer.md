---
name: leaflet.migrationLayer
category: dataviz
repo: https://github.com/lit-forest/leaflet.migrationLayer
author: Sylvenas
author-url: https://github.com/react-map
demo: https://lycheelin.github.io/leaflet.migrationLayer/
compatible-v0:
compatible-v1: true
---

leaflet.migrationLayer is used to show migration data such as population, flight, vehicle, traffic and so on. Data visualization on map.
