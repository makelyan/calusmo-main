---
name: Leaflet.Quadtree
category: dataviz
repo: https://ibesora.github.io/Leaflet.Quadtree/
author: ibesora
author-url: https://github.com/ibesora
demo: https://ibesora.github.io/Leaflet.Quadtree/demos/cullingGeoJSON/demo.html
compatible-v0:
compatible-v1: true
---

Leaflet.Quadtree is used to retrieve visible data inside given bounds
