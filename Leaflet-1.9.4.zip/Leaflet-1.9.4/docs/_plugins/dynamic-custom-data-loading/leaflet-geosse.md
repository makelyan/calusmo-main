---
name: Leaflet GeoSSE
category: dynamic-custom-data-loading
repo: https://github.com/ATran31/Leaflet-GeoSSE
author: An Tran
author-url: https://github.com/ATran31/
demo: 
compatible-v0:
compatible-v1: true
---

Add realtime data to a Leaflet map using server sent events.
