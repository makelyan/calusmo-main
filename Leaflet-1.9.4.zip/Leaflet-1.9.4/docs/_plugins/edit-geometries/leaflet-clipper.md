---
name: Leaflet.Clipper
category: edit-geometries
repo: https://github.com/willfarrell/Leaflet.Clipper
author: will Farrell
author-url: https://github.com/willfarrell
demo: https://willfarrell.github.io/Leaflet.Clipper/
compatible-v0:
compatible-v1: true
---

Allows Union, Difference, Xor, and Intersection operations on two polygons.
