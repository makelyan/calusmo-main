---
name: Leaflet.DraggableLines
category: edit-geometries
repo: https://github.com/FacilMap/Leaflet.DraggableLines
author: Candid Dauth
author-url: https://github.com/cdauth/
demo: https://unpkg.com/leaflet-draggable-lines/example.html
compatible-v0:
compatible-v1: true
---

Add/move/remove points on routes, lines and polygons by drag&amp;drop.
