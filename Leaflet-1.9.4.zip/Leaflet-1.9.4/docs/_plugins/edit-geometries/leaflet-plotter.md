---
name: Leaflet.plotter
category: edit-geometries
repo: https://github.com/scripter-co/leaflet-plotter
author: Nathan Mahdavi
author-url: https://github.com/scripter-co
demo: http://scripter-co.github.io/leaflet-plotter/
compatible-v0:
compatible-v1: true
---

leaflet-plotter allows you to create routes using a leaflet powered map. You can click on the mid-points to create a new, draggable point.
