---
name: Django Leaflet
category: frameworks-build-systems
repo: https://github.com/makinacorpus/django-leaflet
author: Makina Corpus
author-url: https://makina-corpus.com/
demo: 
compatible-v0: true
compatible-v1: true
---

Use Leaflet in your **Django** projects. Includes admin integration, form widget, template tags, and much more!
