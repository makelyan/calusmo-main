---
name: gwty-leaflet
category: frameworks-build-systems
repo: https://github.com/gwidgets/gwty-leaflet
author: Zakaria Amine
author-url: https://github.com/zak905
demo: 
compatible-v0:
compatible-v1: true
---

A Java/GWT JsInterop wrapper for Leaflet. It allows using Leaflet in Java the same way as from a javascript script.
