---
name: Leaflet map component
category: frameworks-build-systems
repo: https://github.com/prtksxna/leaflet-map-component
author: Prateek Saxena
author-url: https://github.com/prtksxna
demo: https://prtksxna.github.io/leaflet-map-component/
compatible-v0:
compatible-v1: true
---

Integrate Leaflet in applications made with the <a href="https://docs-05-dot-polymer-project.appspot.com/0.5/">Polymer 0.5</a> web framework.
