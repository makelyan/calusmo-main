---
name: Leaflet Popup Angular
category: frameworks-build-systems
repo: https://github.com/grantHarris/leaflet-popup-angular
author: Grant Harris
author-url: https://github.com/grantHarris
demo: http://grantharris.github.io/leaflet-popup-angular/examples/examples.html
compatible-v0:
compatible-v1: true
---

Use AngularJS in your Leaflet popups. Extends the built-in L.popup.
