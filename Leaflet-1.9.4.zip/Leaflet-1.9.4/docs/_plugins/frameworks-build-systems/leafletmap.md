---
name: leaflet-map
category: frameworks-build-systems
repo: https://github.com/leaflet-extras/leaflet-map
author: Hendrik Brummermann
author-url: https://github.com/nhnb
demo: https://leaflet-extras.github.io/leaflet-map/demo.html
compatible-v0:
compatible-v1: true
---

Integrate Leaflet in applications made with the <a href="https://polymer-library.polymer-project.org/3.0/docs/devguide/feature-overview">Polymer &gt;= 1.0</a> web component framework.
