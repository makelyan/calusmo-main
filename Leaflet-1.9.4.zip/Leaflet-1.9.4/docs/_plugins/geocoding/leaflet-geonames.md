---
name: Leaflet.Geonames
category: geocoding
repo: https://github.com/consbio/Leaflet.Geonames
author: Brendan Ward
author-url: https://github.com/brendan-ward
demo: https://consbio.github.io/Leaflet.Geonames/
compatible-v0:
compatible-v1: true
---

A lightweight geocoding control powered by <a href="http://www.geonames.org/">GeoNames</a>.
