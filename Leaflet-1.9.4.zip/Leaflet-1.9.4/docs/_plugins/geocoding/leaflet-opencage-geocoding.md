---
name: Leaflet.OpenCage.Geocoding
category: geocoding
repo: https://github.com/OpenCageData/leaflet-opencage-geocoding
author: OpenCage
author-url: https://github.com/opencagedata
demo: https://opencagedata.com/tutorials/geocode-in-leaflet
compatible-v0:
compatible-v1: true
---

A plugin plugin that uses <a href="https://opencagedata.com">OpenCage's geocoding API</a> for forward or reverse geocoding.
