---
name: Leaflet.OpenCage.Geosearch
category: geocoding
repo: https://github.com/OpenCageData/geosearch/tree/master/packages/leaflet-opencage-geosearch
author: OpenCage
author-url: https://github.com/opencagedata
demo: https://opencagedata.com/tutorials/leaflet-location-search
compatible-v0:
compatible-v1: true
---

A plugin that uses <a href="https://opencagedata.com/geosearch">OpenCage's geosearch</a> for location autosuggest.
