---
name: Geolet
category: geolocation
repo: https://github.com/rhlt/leaflet-geolet
author: Ruben Holthuijsen
author-url: https://github.com/rhlt/
demo: https://rubenholthuijsen.nl/geolet/demo
compatible-v0:
compatible-v1: true
---

A simple but highly customizable geolocation plugin for Leaflet
