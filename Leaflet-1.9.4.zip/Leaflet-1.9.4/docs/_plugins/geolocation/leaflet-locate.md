---
name: Leaflet.Locate
category: geolocation
repo: https://github.com/domoritz/leaflet-locatecontrol
author: Dominik Moritz
author-url: https://github.com/domoritz
demo: https://domoritz.github.io/leaflet-locatecontrol/demo/
compatible-v0:
compatible-v1: true
---

A customizable locate control.
