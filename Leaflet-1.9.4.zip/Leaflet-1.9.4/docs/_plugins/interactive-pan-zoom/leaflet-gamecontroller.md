---
name: Leaflet GameController
category: interactive-pan-zoom
repo: https://github.com/SINTEF-9012/Leaflet.GameController
author: Antoine Pultier
author-url: https://github.com/yellowiscool
demo: 
compatible-v0:
compatible-v1: true
---

Interaction handler providing support for gamepads.
