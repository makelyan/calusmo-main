---
name: Leaflet.ZoomLabel
category: interactive-pan-zoom
repo: https://github.com/unbam/Leaflet.ZoomLabel
author: Masashi Takeshita
author-url: https://github.com/unbam
demo: http://unbam.github.io/Leaflet.ZoomLabel/
compatible-v0:
compatible-v1: true
---

A simple zoom label control.
