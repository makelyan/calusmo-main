---
name: Leaflet.ActiveLayers
category: layer-switching-controls
repo: https://github.com/vogdb/Leaflet.ActiveLayers
author: vogdb
author-url: https://github.com/vogdb
demo: 
compatible-v0:
compatible-v1: true
---

Adds new L.Control.ActiveLayers with functionality to get currently active layers on the map.
