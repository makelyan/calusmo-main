---
name: Leaflet.AutoLayers
category: layer-switching-controls
repo: https://github.com/aebadirad/Leaflet.AutoLayers
author: Alex Ebadirad
author-url: https://github.com/aebadirad
demo: 
compatible-v0:
compatible-v1: true
---

Automatically pull layers from multiple mapservers and organize/search them with user controlled overlay zIndex management.
