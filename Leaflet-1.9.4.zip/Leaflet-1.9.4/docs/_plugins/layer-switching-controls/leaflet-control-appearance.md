---
name: Leaflet.Control.Appearance
category: layer-switching-controls
repo: https://github.com/Kanahiro/Leaflet.Control.Appearance
author: Kanahiro Iguchi
author-url: https://www.labo288.site/
demo:
compatible-v0:
compatible-v1: true
---

Extend of Control.Layers, can control Appearances of Layers - color, opacity and able to remove a overlay layer.
