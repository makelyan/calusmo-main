---
name: Leaflet.LayerTreePlugin
category: layer-switching-controls
repo: https://github.com/bambrikii/leaflet-layer-tree-plugin
author: Alexander Arakelyan
author-url: https://github.com/bambrikii
demo: https://rawgit.com/bambrikii/leaflet-layer-tree-plugin/master/examples/basic-example.htm
compatible-v0:
compatible-v1: true
---

Leaflet control allows to switch layers on and off, display them in a tree-like way.
