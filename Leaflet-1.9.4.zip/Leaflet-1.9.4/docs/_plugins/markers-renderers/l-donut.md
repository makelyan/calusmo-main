---
name: L.Donut
category: markers-renderers
repo: https://github.com/Falke-Design/L.Donut
author: Falke-Design
author-url: https://github.com/Falke-Design/
demo: https://falke-design.github.io/L.Donut/
compatible-v0:
compatible-v1: true
---

Extension of L.Circle which allows to define a outer and inner radius.
