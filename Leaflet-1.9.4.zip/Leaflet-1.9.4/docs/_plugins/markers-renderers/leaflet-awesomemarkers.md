---
name: Leaflet.Awesome-Markers
category: markers-renderers
repo: https://github.com/lennardv2/Leaflet.awesome-markers
author: Lennard Voogdt
author-url: https://lennardvoogdt.nl/
demo: https://github.com/lennardv2/Leaflet.awesome-markers#screenshots
compatible-v0:
compatible-v1: true
---

Colorful, iconic &amp; retina-proof markers based on the Font Awesome icons/Twitter Bootstrap icons
