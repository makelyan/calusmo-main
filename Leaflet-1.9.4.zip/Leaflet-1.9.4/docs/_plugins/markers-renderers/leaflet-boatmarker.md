---
name: Leaflet.BoatMarker
category: markers-renderers
repo: https://github.com/thomasbrueggemann/leaflet.boatmarker
author: Thomas Brüggemann
author-url: https://github.com/thomasbrueggemann
demo: http://thomasbrueggemann.github.io/leaflet.boatmarker/
compatible-v0:
compatible-v1: true
---

A boat marker using HTML Canvas for displaying yachts and sailboats with heading and optional wind information.
