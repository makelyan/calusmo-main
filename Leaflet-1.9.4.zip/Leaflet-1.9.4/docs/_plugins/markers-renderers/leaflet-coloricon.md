---
name: Leaflet.ColorIcon
category: markers-renderers
repo: https://github.com/shevekk/Leaflet.ColorIcon
author: Maxence Martin (shevek)
author-url: https://github.com/shevekk
demo: http://dataexplorer.hd.free.fr/Leaflet.ColorIcon/examples/basic/
compatible-v0: false
compatible-v1: true
---

Overwrite color of the icon with CSS filters and make it possible to add same icon-image in different colors.
