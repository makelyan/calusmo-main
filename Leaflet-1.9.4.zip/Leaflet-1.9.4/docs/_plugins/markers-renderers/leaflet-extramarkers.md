---
name: Leaflet.Extra-Markers
category: markers-renderers
repo: https://github.com/coryasilva/Leaflet.ExtraMarkers
author: Cory Silva
author-url: https://www.corysilva.com/
demo: https://coryasilva.github.io/Leaflet.ExtraMarkers/
compatible-v0:
compatible-v1: true
---

Shameless copy of Awesome-Markers with more shapes, colors and semantic-ui support
