---
name: Leaflet.pattern
category: markers-renderers
repo: https://github.com/teastman/Leaflet.pattern
author: Tyler Eastman
author-url: https://github.com/teastman
demo: 
compatible-v0:
compatible-v1: true
---

Add support for pattern fills on Paths.
