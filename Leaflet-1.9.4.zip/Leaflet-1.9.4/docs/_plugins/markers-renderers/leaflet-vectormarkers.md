---
name: Leaflet.VectorMarkers
category: markers-renderers
repo: https://github.com/hiasinho/Leaflet.vector-markers
author: Mathias Schneider
author-url: https://github.com/hiasinho
demo: 
compatible-v0:
compatible-v1: true
---

Vector SVG markers for Leaflet, with an option for Font Awesome/Twitter Bootstrap icons.
