---
name: leaflet-mapkey-icon
category: markers-renderers
repo: https://github.com/mapshakers/leaflet-mapkey-icon
author: mapshakers
author-url: https://github.com/mapshakers
demo: http://mapshakers.com/projects/leaflet-mapkey-icon/
compatible-v0:
compatible-v1: true
---

Set of cartographic font icons based on <a href="https://iconsflow.com">mapkeyicons</a>.
