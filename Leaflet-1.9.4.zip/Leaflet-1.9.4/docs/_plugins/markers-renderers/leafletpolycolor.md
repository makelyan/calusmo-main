---
name: leaflet-polycolor
category: markers-renderers
repo: https://github.com/Oliv/leaflet-polycolor
author: Olivier Gasc
author-url: https://github.com/Oliv
demo: https://oliv.github.io/leaflet-polycolor/
compatible-v0:
compatible-v1: true
---

Color each polyline segment.
