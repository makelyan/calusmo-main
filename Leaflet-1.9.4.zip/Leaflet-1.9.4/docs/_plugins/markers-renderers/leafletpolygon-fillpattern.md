---
name: leaflet-polygon.fillPattern
category: markers-renderers
repo: https://github.com/cloudybay/leaflet-polygon-fillPattern
author: CloudyBay
author-url: https://github.com/cloudybay/
demo: http://lwsu.github.io/leaflet-polygon-fillPattern/example/
compatible-v0:
compatible-v1: true
---

Extend the Polygon Object to fill SVG Path element with an image pattern.
