---
name: Leaflet.MeasureControl
category: measurement
repo: https://github.com/makinacorpus/Leaflet.MeasureControl
author: Makina Corpus
author-url: https://github.com/makinacorpus/
demo: https://makinacorpus.github.io/Leaflet.MeasureControl/
compatible-v0:
compatible-v1: true
---

A simple tool to measure distances on maps (*relies on Leaflet.Draw*).
