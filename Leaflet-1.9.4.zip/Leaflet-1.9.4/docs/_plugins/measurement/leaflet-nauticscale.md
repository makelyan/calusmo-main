---
name: Leaflet.nauticscale
category: measurement
repo: https://github.com/PowerPan/leaflet.nauticscale
author: Johannes Rudolph
author-url: https://github.com/PowerPan
demo:
compatible-v0:
compatible-v1: true
---

Display a Nauticscale on Leaflet maps
