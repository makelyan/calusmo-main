---
name: leaflet.WorldMiniMap
category: minimaps-synced-maps
repo: https://github.com/maneoverland/leaflet.WorldMiniMap
author: M. Friedl
author-url: https://github.com/maneoverland
demo: https://maneoverland.github.io/leaflet.WorldMiniMap/
compatible-v0: false
compatible-v1: true
---

A small minimap showing the map-view on a world-mini-map to aid navigation.