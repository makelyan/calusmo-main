---
name: Leaflet.GlobeMiniMap
category: minimaps-synced-maps
repo: https://github.com/chriswhong/leaflet-globeminimap/
author: Chris Whong
author-url: https://github.com/chriswhong
demo: http://chriswhong.github.io/leaflet-globeminimap/example/
compatible-v0:
compatible-v1: true
---

Simple minimap control that places a 3D Globe in the corner of your map, centered on the same location as the main map.
