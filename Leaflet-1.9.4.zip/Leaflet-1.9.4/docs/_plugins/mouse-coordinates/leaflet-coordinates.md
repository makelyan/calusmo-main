---
name: Leaflet.Coordinates
category: mouse-coordinates
repo: https://github.com/MrMufflon/Leaflet.Coordinates
author: Felix Bache
author-url: https://github.com/MrMufflon
demo: http://mrmufflon.github.io/Leaflet.Coordinates/examples/demo.html
compatible-v0:
compatible-v1: true
---

A simple Leaflet plugin viewing the mouse LatLng-coordinates. Also views a marker with coordinate popup on userinput.
