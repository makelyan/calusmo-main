---
name: Leaflet Location Picker
category: mouse-coordinates
repo: https://github.com/stefanocudini/leaflet-locationpicker
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: https://opengeo.tech/maps/leaflet-locationpicker/
compatible-v0:
compatible-v1: true
---

Simple location picker with mini Leaflet map.
