---
name: Leaflet.MapCenterCoord
category: mouse-coordinates
repo: https://github.com/xguaita/Leaflet.MapCenterCoord
author: Xisco Guaita
author-url: https://github.com/xguaita
demo: http://xguaita.github.io/Leaflet.MapCenterCoord/
compatible-v0:
compatible-v1: true
---

A Leaflet control to display the coordinates of the map center, especially useful on touch/mobile devices.
