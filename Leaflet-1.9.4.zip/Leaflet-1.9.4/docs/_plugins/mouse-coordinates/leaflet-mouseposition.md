---
name: Leaflet.MousePosition
category: mouse-coordinates
repo: https://github.com/ardhi/Leaflet.MousePosition
author: Ardhi Lukianto
author-url: https://github.com/ardhi
demo: 
compatible-v0:
compatible-v1: true
---

A simple MousePosition control that displays geographic coordinates of the mouse pointer, as it is moved about the map
