---
name: TileLayer.DeepZoom
category: non-map-base-layers
repo: https://github.com/alfarisi/leaflet-deepzoom
author: Al Farisi
author-url: https://github.com/alfarisi
demo: 
compatible-v0:
compatible-v1: true
---

A TileLayer for DeepZoom images.
