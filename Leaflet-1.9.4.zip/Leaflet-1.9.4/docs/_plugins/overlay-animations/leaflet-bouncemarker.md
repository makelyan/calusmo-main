---
name: Leaflet.BounceMarker
category: overlay-animations
repo: https://github.com/maximeh/leaflet.bouncemarker
author: Maxime Hadjinlian
author-url: https://github.com/maximeh
demo: https://maximeh.github.io/leaflet.bouncemarker/
compatible-v0:
compatible-v1: true
---

Make a marker bounce when you add it to a map.
