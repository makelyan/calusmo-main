---
name: leaflet.motion
category: overlay-animations
repo: https://github.com/Igor-Vladyka/leaflet.motion
author: Igor Vladyka
author-url: https://github.com/Igor-Vladyka/
demo: https://igor-vladyka.github.io/leaflet.motion/
compatible-v0:
compatible-v1: true
---

Adds simple motion to your polyline with marker in a head on line.
