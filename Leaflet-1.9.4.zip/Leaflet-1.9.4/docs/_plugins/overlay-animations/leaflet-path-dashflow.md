---
name: Leaflet.Path.DashFlow
category: overlay-animations
repo: https://gitlab.com/IvanSanchez/Leaflet.Path.DashFlow
author: Iván Sánchez Ortega
author-url: https://gitlab.com/IvanSanchez
demo: https://ivansanchez.gitlab.io/Leaflet.Path.DashFlow/demo.html
compatible-v0:
compatible-v1: true
---

Animates the dashArray of lines and circles, creating a basic flow effect.
