---
name: Leaflet.Snow
category: overlay-animations
repo: https://github.com/ggolikov/Leaflet.Snow
author: Grigory Golikov
author-url: https://github.com/ggolikov
demo: https://ggolikov.github.io/Leaflet.Snow/
compatible-v0:
compatible-v1: true
---

Customizable WebGL snow animation for Leaflet. Useful for weather maps.
