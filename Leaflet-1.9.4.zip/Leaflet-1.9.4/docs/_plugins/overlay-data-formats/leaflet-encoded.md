---
name: Leaflet.encoded
category: overlay-data-formats
repo: https://github.com/jieter/Leaflet.encoded
author: Jieter
author-url: https://github.com/jieter
demo: 
compatible-v0:
compatible-v1: true
---

Use encoded polylines in Leaflet.
