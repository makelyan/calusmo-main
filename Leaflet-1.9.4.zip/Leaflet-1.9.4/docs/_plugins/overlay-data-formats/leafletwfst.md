---
name: Leaflet-WFST
category: overlay-data-formats
repo: https://github.com/Flexberry/Leaflet-WFST
author: Flexberry
author-url: https://github.com/Flexberry/
demo: 
compatible-v0:
compatible-v1: true
---

<a href="https://www.ogc.org/standards/wfs">WFS</a> client layer with transaction support
