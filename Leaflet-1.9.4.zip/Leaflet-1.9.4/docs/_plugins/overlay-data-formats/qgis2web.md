---
name: qgis2web
category: overlay-data-formats
repo: https://github.com/tomchadwin/qgis2web
author: Tom Chadwin
author-url: https://github.com/tomchadwin
demo: 
compatible-v0:
compatible-v1: true
---

A <a href="https://qgis.org/">QGIS</a> plugin to make webmaps without coding.
