---
name: Wicket
category: overlay-data-formats
repo: https://github.com/arthur-e/Wicket/
author: K. Arthur Endsley
author-url: https://github.com/arthur-e/
demo: https://arthur-e.github.io/Wicket/
compatible-v0:
compatible-v1: true
---

A modest library for translating between Well-Known Text (WKT) and Leaflet geometry objects (e.g. between L.marker() instances and "POINT()" strings).
